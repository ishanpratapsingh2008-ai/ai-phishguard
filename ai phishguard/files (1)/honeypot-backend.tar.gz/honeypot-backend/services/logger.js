const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');

// Define log levels
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
};

// Define colors for each log level
const colors = {
  error: 'red',
  warn: 'yellow',
  info: 'green',
  http: 'magenta',
  debug: 'blue',
};

// Tell winston about our colors
winston.addColors(colors);

// Define log format
const format = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

// Console format with colors
const consoleFormat = winston.format.combine(
  winston.format.colorize({ all: true }),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(
    (info) => `${info.timestamp} [${info.level}]: ${info.message}`
  )
);

// Determine log level based on environment
const level = () => {
  const env = process.env.NODE_ENV || 'development';
  const isDevelopment = env === 'development';
  return isDevelopment ? 'debug' : 'info';
};

// Define transports
const transports = [
  // Console transport
  new winston.transports.Console({
    format: consoleFormat,
  }),
  
  // File transport for all logs
  new DailyRotateFile({
    filename: path.join(process.env.LOG_FILE_PATH || './logs', 'application-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: '20m',
    maxFiles: '14d',
    format: format,
  }),
  
  // Separate file for errors only
  new DailyRotateFile({
    filename: path.join(process.env.LOG_FILE_PATH || './logs', 'error-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: '20m',
    maxFiles: '30d',
    level: 'error',
    format: format,
  }),
  
  // Separate file for HTTP requests
  new DailyRotateFile({
    filename: path.join(process.env.LOG_FILE_PATH || './logs', 'http-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: '20m',
    maxFiles: '7d',
    level: 'http',
    format: format,
  }),
];

// Create the logger
const logger = winston.createLogger({
  level: level(),
  levels,
  format,
  transports,
  exitOnError: false,
});

// Create specialized loggers for different components

/**
 * Security event logger
 */
const securityLogger = winston.createLogger({
  level: 'info',
  format,
  transports: [
    new DailyRotateFile({
      filename: path.join(process.env.LOG_FILE_PATH || './logs', 'security-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '90d', // Keep security logs for 90 days
    }),
  ],
});

/**
 * Session activity logger
 */
const sessionLogger = winston.createLogger({
  level: 'info',
  format,
  transports: [
    new DailyRotateFile({
      filename: path.join(process.env.LOG_FILE_PATH || './logs', 'sessions-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '30d',
    }),
  ],
});

/**
 * Intelligence capture logger
 */
const intelligenceLogger = winston.createLogger({
  level: 'info',
  format,
  transports: [
    new DailyRotateFile({
      filename: path.join(process.env.LOG_FILE_PATH || './logs', 'intelligence-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '90d',
    }),
  ],
});

/**
 * Helper functions for structured logging
 */

function logSessionEvent(event, data) {
  sessionLogger.info({
    event,
    ...data,
    timestamp: new Date().toISOString(),
  });
}

function logIntelligenceCapture(captureData) {
  intelligenceLogger.info({
    event: 'INTELLIGENCE_CAPTURE',
    ...captureData,
    timestamp: new Date().toISOString(),
  });
}

function logSecurityEvent(event, severity, data) {
  securityLogger.log(severity, {
    event,
    ...data,
    timestamp: new Date().toISOString(),
  });
}

function logAPIRequest(req, res, duration) {
  logger.http({
    method: req.method,
    url: req.url,
    status: res.statusCode,
    duration: `${duration}ms`,
    ip: req.ip || req.connection.remoteAddress,
    userAgent: req.get('user-agent'),
    timestamp: new Date().toISOString(),
  });
}

function logError(error, context = {}) {
  logger.error({
    message: error.message,
    stack: error.stack,
    ...context,
    timestamp: new Date().toISOString(),
  });
}

function logWarning(message, data = {}) {
  logger.warn({
    message,
    ...data,
    timestamp: new Date().toISOString(),
  });
}

function logInfo(message, data = {}) {
  logger.info({
    message,
    ...data,
    timestamp: new Date().toISOString(),
  });
}

function logDebug(message, data = {}) {
  logger.debug({
    message,
    ...data,
    timestamp: new Date().toISOString(),
  });
}

/**
 * Express middleware for request logging
 */
function requestLogger(req, res, next) {
  const startTime = Date.now();

  // Log when response finishes
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    logAPIRequest(req, res, duration);
  });

  next();
}

/**
 * Error logging middleware
 */
function errorLogger(err, req, res, next) {
  logError(err, {
    method: req.method,
    url: req.url,
    ip: req.ip,
    body: req.body,
  });
  next(err);
}

module.exports = {
  logger,
  securityLogger,
  sessionLogger,
  intelligenceLogger,
  logSessionEvent,
  logIntelligenceCapture,
  logSecurityEvent,
  logAPIRequest,
  logError,
  logWarning,
  logInfo,
  logDebug,
  requestLogger,
  errorLogger,
};
