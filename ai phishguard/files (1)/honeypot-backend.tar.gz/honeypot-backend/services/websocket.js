const WebSocket = require('ws');
const url = require('url');
const jwt = require('jsonwebtoken');

class WebSocketManager {
  constructor(server) {
    this.wss = new WebSocket.Server({ 
      server,
      verifyClient: this.verifyClient.bind(this)
    });
    
    this.clients = new Map(); // Map of client ID to WebSocket connection
    this.subscriptions = new Map(); // Map of topic to Set of client IDs
    
    this.setupEventHandlers();
  }

  /**
   * Verify client connection (optional authentication)
   */
  verifyClient(info, callback) {
    const params = url.parse(info.req.url, true).query;
    const token = params.token;

    // Allow connections without token for now (can be enforced later)
    if (!token) {
      return callback(true);
    }

    try {
      jwt.verify(token, process.env.JWT_SECRET);
      callback(true);
    } catch (error) {
      callback(false, 401, 'Unauthorized');
    }
  }

  /**
   * Setup WebSocket event handlers
   */
  setupEventHandlers() {
    this.wss.on('connection', (ws, req) => {
      const clientId = this.generateClientId();
      this.clients.set(clientId, ws);

      console.log(`WebSocket client connected: ${clientId}`);
      console.log(`Total connected clients: ${this.clients.size}`);

      // Send welcome message
      this.sendToClient(clientId, {
        type: 'CONNECTED',
        clientId,
        timestamp: new Date().toISOString(),
      });

      // Handle incoming messages
      ws.on('message', (message) => {
        this.handleClientMessage(clientId, message);
      });

      // Handle client disconnect
      ws.on('close', () => {
        this.handleClientDisconnect(clientId);
      });

      // Handle errors
      ws.on('error', (error) => {
        console.error(`WebSocket error for client ${clientId}:`, error);
        this.handleClientDisconnect(clientId);
      });

      // Send ping to keep connection alive
      const pingInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.ping();
        } else {
          clearInterval(pingInterval);
        }
      }, 30000); // Ping every 30 seconds

      ws.on('pong', () => {
        // Client is still alive
      });
    });
  }

  /**
   * Generate unique client ID
   */
  generateClientId() {
    return `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Handle messages from clients
   */
  handleClientMessage(clientId, message) {
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'SUBSCRIBE':
          this.subscribeClient(clientId, data.topics || []);
          break;
        
        case 'UNSUBSCRIBE':
          this.unsubscribeClient(clientId, data.topics || []);
          break;
        
        case 'PING':
          this.sendToClient(clientId, { type: 'PONG', timestamp: new Date().toISOString() });
          break;
        
        default:
          console.log(`Unknown message type from ${clientId}:`, data.type);
      }
    } catch (error) {
      console.error(`Error processing message from ${clientId}:`, error);
    }
  }

  /**
   * Subscribe client to topics
   */
  subscribeClient(clientId, topics) {
    topics.forEach(topic => {
      if (!this.subscriptions.has(topic)) {
        this.subscriptions.set(topic, new Set());
      }
      this.subscriptions.get(topic).add(clientId);
    });

    this.sendToClient(clientId, {
      type: 'SUBSCRIBED',
      topics,
      timestamp: new Date().toISOString(),
    });

    console.log(`Client ${clientId} subscribed to:`, topics);
  }

  /**
   * Unsubscribe client from topics
   */
  unsubscribeClient(clientId, topics) {
    topics.forEach(topic => {
      const subscribers = this.subscriptions.get(topic);
      if (subscribers) {
        subscribers.delete(clientId);
        if (subscribers.size === 0) {
          this.subscriptions.delete(topic);
        }
      }
    });

    this.sendToClient(clientId, {
      type: 'UNSUBSCRIBED',
      topics,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Handle client disconnect
   */
  handleClientDisconnect(clientId) {
    // Remove from all subscriptions
    this.subscriptions.forEach((subscribers, topic) => {
      subscribers.delete(clientId);
      if (subscribers.size === 0) {
        this.subscriptions.delete(topic);
      }
    });

    // Remove client
    this.clients.delete(clientId);
    console.log(`Client ${clientId} disconnected`);
    console.log(`Total connected clients: ${this.clients.size}`);
  }

  /**
   * Send message to specific client
   */
  sendToClient(clientId, data) {
    const ws = this.clients.get(clientId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  }

  /**
   * Broadcast to all connected clients
   */
  broadcast(data) {
    const message = JSON.stringify(data);
    this.clients.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  /**
   * Broadcast to clients subscribed to specific topic
   */
  broadcastToTopic(topic, data) {
    const subscribers = this.subscriptions.get(topic);
    if (!subscribers || subscribers.size === 0) {
      return;
    }

    const message = JSON.stringify({
      ...data,
      topic,
    });

    subscribers.forEach((clientId) => {
      const ws = this.clients.get(clientId);
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  /**
   * Broadcast new session event
   */
  broadcastNewSession(sessionData) {
    this.broadcastToTopic('sessions', {
      type: 'NEW_SESSION',
      data: sessionData,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast new intelligence capture
   */
  broadcastNewCapture(captureData) {
    this.broadcastToTopic('intelligence', {
      type: 'NEW_CAPTURE',
      data: captureData,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast terminal log
   */
  broadcastTerminalLog(logData) {
    this.broadcastToTopic('terminal', {
      type: 'TERMINAL_LOG',
      data: logData,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast statistics update
   */
  broadcastStatsUpdate(stats) {
    this.broadcastToTopic('stats', {
      type: 'STATS_UPDATE',
      data: stats,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast session update
   */
  broadcastSessionUpdate(sessionId, updateData) {
    this.broadcastToTopic('sessions', {
      type: 'SESSION_UPDATE',
      sessionId,
      data: updateData,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast alert/warning
   */
  broadcastAlert(alert) {
    this.broadcast({
      type: 'ALERT',
      severity: alert.severity || 'info',
      message: alert.message,
      data: alert.data || {},
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Get connection statistics
   */
  getStats() {
    const topicStats = {};
    this.subscriptions.forEach((subscribers, topic) => {
      topicStats[topic] = subscribers.size;
    });

    return {
      totalClients: this.clients.size,
      subscriptions: topicStats,
      totalTopics: this.subscriptions.size,
    };
  }

  /**
   * Close all connections and cleanup
   */
  shutdown() {
    console.log('Shutting down WebSocket server...');
    
    // Send shutdown notice to all clients
    this.broadcast({
      type: 'SERVER_SHUTDOWN',
      message: 'Server is shutting down',
      timestamp: new Date().toISOString(),
    });

    // Close all client connections
    this.clients.forEach((ws) => {
      ws.close(1000, 'Server shutdown');
    });

    // Close WebSocket server
    this.wss.close(() => {
      console.log('WebSocket server closed');
    });
  }
}

module.exports = WebSocketManager;
