const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { pool } = require('../server');

/**
 * API Key Authentication Middleware
 */
async function authenticateApiKey(req, res, next) {
  try {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
      return res.status(401).json({
        error: 'Authentication required',
        message: 'API key is missing',
      });
    }

    // Hash the provided API key
    const keyHash = crypto
      .createHash('sha256')
      .update(apiKey)
      .digest('hex');

    // Verify against database
    const result = await pool.query(
      `SELECT id, name, permissions, is_active, expires_at 
       FROM api_keys 
       WHERE key_hash = $1`,
      [keyHash]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: 'Invalid API key',
      });
    }

    const key = result.rows[0];

    // Check if key is active
    if (!key.is_active) {
      return res.status(401).json({
        error: 'API key is inactive',
      });
    }

    // Check if key is expired
    if (key.expires_at && new Date(key.expires_at) < new Date()) {
      return res.status(401).json({
        error: 'API key has expired',
      });
    }

    // Update last_used timestamp
    await pool.query(
      'UPDATE api_keys SET last_used = NOW() WHERE id = $1',
      [key.id]
    );

    // Attach key info to request
    req.apiKey = {
      id: key.id,
      name: key.name,
      permissions: key.permissions,
    };

    next();
  } catch (error) {
    console.error('API key authentication error:', error);
    res.status(500).json({
      error: 'Authentication failed',
    });
  }
}

/**
 * JWT Authentication Middleware (for user sessions)
 */
function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Authentication required',
      message: 'JWT token is missing',
    });
  }

  const token = authHeader.substring(7);

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'Token expired',
        message: 'Please login again',
      });
    }
    return res.status(401).json({
      error: 'Invalid token',
    });
  }
}

/**
 * Permission checking middleware
 */
function requirePermission(...permissions) {
  return (req, res, next) => {
    if (!req.apiKey && !req.user) {
      return res.status(401).json({
        error: 'Authentication required',
      });
    }

    const userPermissions = req.apiKey?.permissions || req.user?.permissions || {};

    const hasPermission = permissions.every((perm) => {
      return userPermissions[perm] === true;
    });

    if (!hasPermission) {
      return res.status(403).json({
        error: 'Insufficient permissions',
        required: permissions,
      });
    }

    next();
  };
}

/**
 * Generate a new API key
 */
function generateApiKey() {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Hash an API key
 */
function hashApiKey(apiKey) {
  return crypto
    .createHash('sha256')
    .update(apiKey)
    .digest('hex');
}

/**
 * Create a new API key in the database
 */
async function createApiKey(name, permissions = {}, expiresInDays = null) {
  const apiKey = generateApiKey();
  const keyHash = hashApiKey(apiKey);

  const expiresAt = expiresInDays
    ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
    : null;

  await pool.query(
    `INSERT INTO api_keys (key_hash, name, permissions, expires_at)
     VALUES ($1, $2, $3, $4)`,
    [keyHash, name, JSON.stringify(permissions), expiresAt]
  );

  return apiKey; // Return the unhashed key (only time it's visible)
}

/**
 * Generate JWT token
 */
function generateJWT(payload, expiresIn = '24h') {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn,
    issuer: 'honeypot-backend',
  });
}

/**
 * Refresh JWT token
 */
function refreshJWT(token) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET, {
      ignoreExpiration: true,
    });

    // Remove JWT specific fields
    delete decoded.iat;
    delete decoded.exp;
    delete decoded.iss;

    // Generate new token
    return generateJWT(decoded);
  } catch (error) {
    throw new Error('Invalid token for refresh');
  }
}

/**
 * Input validation middleware using Joi
 */
function validateRequest(schema) {
  return (req, res, next) => {
    const { error } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const errors = error.details.map((detail) => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));

      return res.status(400).json({
        error: 'Validation failed',
        details: errors,
      });
    }

    next();
  };
}

/**
 * Rate limit bypass for trusted IPs
 */
function isTrustedIP(req) {
  const trustedIPs = (process.env.TRUSTED_IPS || '').split(',').filter(Boolean);
  const clientIP = req.ip || req.connection.remoteAddress;

  return trustedIPs.includes(clientIP);
}

module.exports = {
  authenticateApiKey,
  authenticateJWT,
  requirePermission,
  generateApiKey,
  hashApiKey,
  createApiKey,
  generateJWT,
  refreshJWT,
  validateRequest,
  isTrustedIP,
};
