-- Database Schema for Honeypot Cybersecurity Dashboard
-- PostgreSQL 14+

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Interception Sessions Table
CREATE TABLE IF NOT EXISTS interception_sessions (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(100) UNIQUE NOT NULL,
    scammer_id VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    location VARCHAR(200),
    persona_type VARCHAR(50),
    detected_intent VARCHAR(100),
    engagement_duration DECIMAL(10, 2) DEFAULT 0,
    data_points_collected INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    last_activity TIMESTAMP DEFAULT NOW(),
    ended_at TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Create indexes for better query performance
CREATE INDEX idx_sessions_scammer_id ON interception_sessions(scammer_id);
CREATE INDEX idx_sessions_phone ON interception_sessions(phone_number);
CREATE INDEX idx_sessions_status ON interception_sessions(status);
CREATE INDEX idx_sessions_created_at ON interception_sessions(created_at DESC);
CREATE INDEX idx_sessions_location ON interception_sessions(location);

-- Intelligence Captures Table
CREATE TABLE IF NOT EXISTS intelligence_captures (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    capture_type VARCHAR(50) NOT NULL,
    captured_data JSONB NOT NULL,
    risk_score INTEGER CHECK (risk_score BETWEEN 0 AND 100),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    FOREIGN KEY (session_id) REFERENCES interception_sessions(session_id) ON DELETE CASCADE
);

CREATE INDEX idx_captures_session_id ON intelligence_captures(session_id);
CREATE INDEX idx_captures_type ON intelligence_captures(capture_type);
CREATE INDEX idx_captures_created_at ON intelligence_captures(created_at DESC);
CREATE INDEX idx_captures_risk_score ON intelligence_captures(risk_score DESC);

-- Session Messages Table (conversation logs)
CREATE TABLE IF NOT EXISTS session_messages (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    sender VARCHAR(20) NOT NULL CHECK (sender IN ('scammer', 'honeypot')),
    message TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb,
    FOREIGN KEY (session_id) REFERENCES interception_sessions(session_id) ON DELETE CASCADE
);

CREATE INDEX idx_messages_session_id ON session_messages(session_id);
CREATE INDEX idx_messages_timestamp ON session_messages(timestamp DESC);

-- Terminal Logs Table
CREATE TABLE IF NOT EXISTS terminal_logs (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(100),
    log_type VARCHAR(20) NOT NULL CHECK (log_type IN ('success', 'warning', 'analyzing', 'error', 'info')),
    message TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_logs_session_id ON terminal_logs(session_id);
CREATE INDEX idx_logs_type ON terminal_logs(log_type);
CREATE INDEX idx_logs_timestamp ON terminal_logs(timestamp DESC);

-- Authority Reports Table
CREATE TABLE IF NOT EXISTS authority_reports (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    report_type VARCHAR(50) NOT NULL,
    additional_info JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(20) DEFAULT 'pending',
    submitted_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    reviewed_at TIMESTAMP,
    reviewer_notes TEXT,
    FOREIGN KEY (session_id) REFERENCES interception_sessions(session_id) ON DELETE CASCADE
);

CREATE INDEX idx_reports_session_id ON authority_reports(session_id);
CREATE INDEX idx_reports_status ON authority_reports(status);
CREATE INDEX idx_reports_created_at ON authority_reports(created_at DESC);

-- Scammer Profiles Table (aggregated intelligence)
CREATE TABLE IF NOT EXISTS scammer_profiles (
    id BIGSERIAL PRIMARY KEY,
    scammer_id VARCHAR(100) UNIQUE NOT NULL,
    phone_numbers TEXT[] DEFAULT ARRAY[]::TEXT[],
    upi_ids TEXT[] DEFAULT ARRAY[]::TEXT[],
    bank_accounts TEXT[] DEFAULT ARRAY[]::TEXT[],
    known_locations TEXT[] DEFAULT ARRAY[]::TEXT[],
    known_tactics TEXT[] DEFAULT ARRAY[]::TEXT[],
    total_interceptions INTEGER DEFAULT 0,
    total_data_points INTEGER DEFAULT 0,
    risk_level VARCHAR(20) DEFAULT 'medium',
    first_seen TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    notes TEXT,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_profiles_scammer_id ON scammer_profiles(scammer_id);
CREATE INDEX idx_profiles_risk_level ON scammer_profiles(risk_level);
CREATE INDEX idx_profiles_phone_numbers ON scammer_profiles USING GIN(phone_numbers);

-- Analytics Summary Table (for caching)
CREATE TABLE IF NOT EXISTS analytics_summary (
    id BIGSERIAL PRIMARY KEY,
    summary_date DATE UNIQUE NOT NULL,
    total_interceptions INTEGER DEFAULT 0,
    total_data_points INTEGER DEFAULT 0,
    unique_scammers INTEGER DEFAULT 0,
    avg_engagement_time DECIMAL(10, 2) DEFAULT 0,
    top_threat_types JSONB DEFAULT '[]'::jsonb,
    top_locations JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_analytics_date ON analytics_summary(summary_date DESC);

-- System Events Table (audit log)
CREATE TABLE IF NOT EXISTS system_events (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    event_data JSONB NOT NULL,
    severity VARCHAR(20) DEFAULT 'info',
    source VARCHAR(100),
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_events_type ON system_events(event_type);
CREATE INDEX idx_events_severity ON system_events(severity);
CREATE INDEX idx_events_timestamp ON system_events(timestamp DESC);

-- API Keys Table (for authentication)
CREATE TABLE IF NOT EXISTS api_keys (
    id BIGSERIAL PRIMARY KEY,
    key_hash VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    permissions JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    last_used TIMESTAMP,
    expires_at TIMESTAMP
);

CREATE INDEX idx_api_keys_hash ON api_keys(key_hash);
CREATE INDEX idx_api_keys_active ON api_keys(is_active);

-- Function to update last_activity on sessions
CREATE OR REPLACE FUNCTION update_session_activity()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE interception_sessions
    SET last_activity = NOW()
    WHERE session_id = NEW.session_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update session activity when new messages arrive
CREATE TRIGGER trigger_update_session_activity
AFTER INSERT ON session_messages
FOR EACH ROW
EXECUTE FUNCTION update_session_activity();

-- Function to calculate engagement duration
CREATE OR REPLACE FUNCTION calculate_engagement_duration()
RETURNS TRIGGER AS $$
BEGIN
    NEW.engagement_duration := EXTRACT(EPOCH FROM (NEW.ended_at - NEW.created_at)) / 60.0;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to calculate duration when session ends
CREATE TRIGGER trigger_calculate_engagement
BEFORE UPDATE OF ended_at ON interception_sessions
FOR EACH ROW
WHEN (NEW.ended_at IS NOT NULL AND OLD.ended_at IS NULL)
EXECUTE FUNCTION calculate_engagement_duration();

-- Function to update scammer profile
CREATE OR REPLACE FUNCTION update_scammer_profile()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO scammer_profiles (scammer_id, total_interceptions, last_seen)
    VALUES (NEW.scammer_id, 1, NEW.created_at)
    ON CONFLICT (scammer_id) 
    DO UPDATE SET
        total_interceptions = scammer_profiles.total_interceptions + 1,
        last_seen = NEW.created_at;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update scammer profile on new session
CREATE TRIGGER trigger_update_scammer_profile
AFTER INSERT ON interception_sessions
FOR EACH ROW
EXECUTE FUNCTION update_scammer_profile();

-- Insert sample data for development
INSERT INTO interception_sessions (
    session_id, scammer_id, phone_number, location, 
    persona_type, detected_intent, engagement_duration, 
    data_points_collected, status
) VALUES
    ('session_1706700001_abc123', 'scammer_001', '+91-7654321098', 'Bengaluru, Karnataka', 'Confused Persona', 'UPI Phishing', 9.3, 5, 'completed'),
    ('session_1706700002_def456', 'scammer_002', '+91-9876543210', 'Mumbai, Maharashtra', 'Elderly Persona', 'Tech Support Scam', 12.7, 8, 'completed'),
    ('session_1706700003_ghi789', 'scammer_003', '+91-8765432109', 'Delhi, NCR', 'Curious Persona', 'Lottery Scam', 6.4, 3, 'active')
ON CONFLICT (session_id) DO NOTHING;

INSERT INTO intelligence_captures (
    session_id, capture_type, captured_data, risk_score
) VALUES
    ('session_1706700001_abc123', 'UPI_ID', '{"upi_id": "scammer123@paytm", "timestamp": "2026-01-31T10:30:00Z"}', 85),
    ('session_1706700001_abc123', 'PHONE', '{"phone": "+91-7654321098", "verified": true}', 90),
    ('session_1706700001_abc123', 'LOCATION', '{"city": "Bengaluru", "state": "Karnataka", "ip": "103.x.x.x"}', 75),
    ('session_1706700002_def456', 'BANK_DETAILS', '{"bank": "SBI", "account_hint": "****1234"}', 95),
    ('session_1706700002_def456', 'SCRIPT', '{"type": "tech_support", "keywords": ["virus", "payment", "remote_access"]}', 80)
ON CONFLICT DO NOTHING;

INSERT INTO terminal_logs (session_id, log_type, message) VALUES
    ('session_1706700003_ghi789', 'success', 'Connection established with scammer endpoint'),
    ('session_1706700003_ghi789', 'analyzing', 'Analyzing scammer intent...'),
    ('session_1706700003_ghi789', 'warning', 'Detected lottery scam attempt'),
    ('session_1706700003_ghi789', 'analyzing', 'Deploying "Curious Persona" strategy...'),
    ('session_1706700003_ghi789', 'success', 'Persona activated - scammer engagement initiated')
ON CONFLICT DO NOTHING;

-- Create views for common queries
CREATE OR REPLACE VIEW v_active_sessions_detail AS
SELECT 
    s.session_id,
    s.scammer_id,
    s.phone_number,
    s.location,
    s.persona_type,
    s.detected_intent,
    s.engagement_duration,
    s.data_points_collected,
    s.created_at,
    s.last_activity,
    COUNT(DISTINCT ic.id) as total_captures,
    array_agg(DISTINCT ic.capture_type) as capture_types
FROM interception_sessions s
LEFT JOIN intelligence_captures ic ON s.session_id = ic.session_id
WHERE s.status = 'active'
GROUP BY s.id, s.session_id, s.scammer_id, s.phone_number, 
         s.location, s.persona_type, s.detected_intent, 
         s.engagement_duration, s.data_points_collected, 
         s.created_at, s.last_activity
ORDER BY s.last_activity DESC;

CREATE OR REPLACE VIEW v_threat_intelligence_summary AS
SELECT 
    detected_intent as threat_type,
    COUNT(*) as total_cases,
    COUNT(DISTINCT scammer_id) as unique_scammers,
    AVG(engagement_duration) as avg_duration,
    SUM(data_points_collected) as total_data_points,
    array_agg(DISTINCT location) as common_locations
FROM interception_sessions
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY detected_intent
ORDER BY total_cases DESC;

-- Grant permissions (adjust as needed for your setup)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO honeypot_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO honeypot_user;

COMMENT ON TABLE interception_sessions IS 'Main table storing all scammer interception sessions';
COMMENT ON TABLE intelligence_captures IS 'Stores individual pieces of intelligence captured during sessions';
COMMENT ON TABLE scammer_profiles IS 'Aggregated profiles of known scammers across multiple sessions';
COMMENT ON TABLE authority_reports IS 'Reports submitted to law enforcement and authorities';
