const Joi = require('joi');

/**
 * Session creation validation schema
 */
const createSessionSchema = Joi.object({
  scammerId: Joi.string()
    .required()
    .max(100)
    .description('Unique identifier for the scammer'),
  
  phoneNumber: Joi.string()
    .pattern(/^\+?[1-9]\d{1,14}$/)
    .required()
    .description('Phone number in E.164 format'),
  
  initialMessage: Joi.string()
    .required()
    .max(1000)
    .description('Initial message from the scammer'),
  
  detectedIntent: Joi.string()
    .required()
    .max(100)
    .description('Detected scam type'),
  
  location: Joi.string()
    .max(200)
    .optional()
    .description('Geographic location'),
  
  personaType: Joi.string()
    .valid('Confused Persona', 'Elderly Persona', 'Curious Persona', 'Busy Persona', 'Tech-Savvy Persona')
    .required()
    .description('AI persona type to use'),
});

/**
 * Intelligence capture validation schema
 */
const intelligenceCaptureSchema = Joi.object({
  sessionId: Joi.string()
    .required()
    .max(100)
    .description('Session identifier'),
  
  captureType: Joi.string()
    .valid('UPI_ID', 'PHONE', 'LOCATION', 'BANK_DETAILS', 'EMAIL', 'SCRIPT', 'METADATA', 'SCREENSHOT')
    .required()
    .description('Type of intelligence captured'),
  
  capturedData: Joi.object()
    .required()
    .description('The actual captured data'),
  
  riskScore: Joi.number()
    .integer()
    .min(0)
    .max(100)
    .required()
    .description('Risk assessment score (0-100)'),
  
  metadata: Joi.object()
    .optional()
    .description('Additional metadata'),
});

/**
 * Authority report validation schema
 */
const authorityReportSchema = Joi.object({
  sessionId: Joi.string()
    .required()
    .max(100)
    .description('Session to report'),
  
  reportType: Joi.string()
    .valid('CYBER_CRIME', 'FINANCIAL_FRAUD', 'EMERGENCY', 'INFORMATION_ONLY')
    .required()
    .description('Type of report'),
  
  additionalInfo: Joi.object({
    urgency: Joi.string()
      .valid('low', 'medium', 'high', 'critical')
      .optional(),
    evidence: Joi.array()
      .items(Joi.string())
      .optional(),
    notes: Joi.string()
      .max(2000)
      .optional(),
  })
    .optional()
    .description('Additional report information'),
});

/**
 * Scammer search validation schema
 */
const scammerSearchSchema = Joi.object({
  phone: Joi.string()
    .max(20)
    .optional(),
  
  upiId: Joi.string()
    .max(100)
    .optional(),
  
  location: Joi.string()
    .max(200)
    .optional(),
  
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(20)
    .optional(),
}).min(1); // At least one search parameter required

/**
 * Pagination validation schema
 */
const paginationSchema = Joi.object({
  limit: Joi.number()
    .integer()
    .min(1)
    .max(500)
    .default(50)
    .optional(),
  
  offset: Joi.number()
    .integer()
    .min(0)
    .default(0)
    .optional(),
});

/**
 * Terminal log query validation schema
 */
const terminalLogQuerySchema = Joi.object({
  limit: Joi.number()
    .integer()
    .min(1)
    .max(1000)
    .default(100)
    .optional(),
  
  sessionId: Joi.string()
    .max(100)
    .optional(),
  
  logType: Joi.string()
    .valid('success', 'warning', 'analyzing', 'error', 'info')
    .optional(),
});

/**
 * Session message validation schema
 */
const sessionMessageSchema = Joi.object({
  sessionId: Joi.string()
    .required()
    .max(100),
  
  sender: Joi.string()
    .valid('scammer', 'honeypot')
    .required(),
  
  message: Joi.string()
    .required()
    .max(5000),
  
  metadata: Joi.object()
    .optional(),
});

/**
 * API key creation validation schema
 */
const createApiKeySchema = Joi.object({
  name: Joi.string()
    .required()
    .max(100)
    .description('Name for the API key'),
  
  permissions: Joi.object()
    .optional()
    .description('Permission object'),
  
  expiresInDays: Joi.number()
    .integer()
    .min(1)
    .max(365)
    .optional()
    .description('Expiry in days (1-365)'),
});

/**
 * Stats query validation schema
 */
const statsQuerySchema = Joi.object({
  period: Joi.string()
    .valid('24h', '7d', '30d', '90d')
    .default('24h')
    .optional(),
  
  startDate: Joi.date()
    .iso()
    .optional(),
  
  endDate: Joi.date()
    .iso()
    .min(Joi.ref('startDate'))
    .optional(),
});

/**
 * WebSocket subscription validation schema
 */
const wsSubscriptionSchema = Joi.object({
  type: Joi.string()
    .valid('SUBSCRIBE', 'UNSUBSCRIBE')
    .required(),
  
  topics: Joi.array()
    .items(Joi.string().valid('sessions', 'intelligence', 'terminal', 'stats'))
    .min(1)
    .required(),
});

module.exports = {
  createSessionSchema,
  intelligenceCaptureSchema,
  authorityReportSchema,
  scammerSearchSchema,
  paginationSchema,
  terminalLogQuerySchema,
  sessionMessageSchema,
  createApiKeySchema,
  statsQuerySchema,
  wsSubscriptionSchema,
};
