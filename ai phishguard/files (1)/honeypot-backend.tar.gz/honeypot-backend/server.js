const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const compression = require('compression');
const { Pool } = require('pg');
const Redis = require('ioredis');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Database connection
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'honeypot_db',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Redis connection for caching and real-time data
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
  retryStrategy: (times) => Math.min(times * 50, 2000),
});

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.jsdelivr.net'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
    },
  },
}));
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('combined'));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: 'Too many requests from this IP, please try again later.',
});
app.use('/api/', limiter);

// WebSocket connection handling
const clients = new Set();

wss.on('connection', (ws, req) => {
  console.log('New WebSocket client connected');
  clients.add(ws);

  ws.on('close', () => {
    console.log('WebSocket client disconnected');
    clients.delete(ws);
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    clients.delete(ws);
  });
});

// Broadcast to all connected clients
function broadcast(data) {
  const message = JSON.stringify(data);
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// API Routes

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    await redis.ping();
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        redis: 'connected',
        websocket: `${clients.size} clients`,
      },
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      error: error.message,
    });
  }
});

// Get dashboard statistics
app.get('/api/stats/overview', async (req, res) => {
  try {
    const cacheKey = 'stats:overview';
    const cached = await redis.get(cacheKey);

    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const result = await pool.query(`
      SELECT 
        COUNT(DISTINCT session_id) as total_interceptions,
        SUM(data_points_collected) as total_data_points,
        AVG(engagement_duration) as avg_engagement,
        COUNT(DISTINCT scammer_id) as unique_scammers,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_sessions
      FROM interception_sessions
      WHERE created_at >= NOW() - INTERVAL '30 days'
    `);

    const stats = {
      totalInterceptions: result.rows[0].total_interceptions || 0,
      dataPointsCollected: result.rows[0].total_data_points || 0,
      avgEngagementTime: parseFloat(result.rows[0].avg_engagement || 0).toFixed(1),
      uniqueScammers: result.rows[0].unique_scammers || 0,
      activeSessions: result.rows[0].active_sessions || 0,
      systemStatus: 'operational',
      timestamp: new Date().toISOString(),
    };

    await redis.setex(cacheKey, 30, JSON.stringify(stats));
    res.json(stats);
  } catch (error) {
    console.error('Error fetching overview stats:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// Get engagement timeline data
app.get('/api/stats/engagement-timeline', async (req, res) => {
  try {
    const { period = '24h' } = req.query;
    const cacheKey = `stats:engagement:${period}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const intervalMap = {
      '24h': '1 hour',
      '7d': '1 day',
      '30d': '1 day',
    };

    const result = await pool.query(`
      SELECT 
        DATE_TRUNC('hour', created_at) as time_bucket,
        AVG(engagement_duration) as avg_engagement,
        COUNT(*) as session_count
      FROM interception_sessions
      WHERE created_at >= NOW() - INTERVAL '24 hours'
      GROUP BY time_bucket
      ORDER BY time_bucket ASC
    `);

    const data = result.rows.map(row => ({
      timestamp: row.time_bucket,
      avgEngagement: parseFloat(row.avg_engagement).toFixed(2),
      sessionCount: parseInt(row.session_count),
    }));

    await redis.setex(cacheKey, 300, JSON.stringify(data));
    res.json(data);
  } catch (error) {
    console.error('Error fetching engagement timeline:', error);
    res.status(500).json({ error: 'Failed to fetch engagement data' });
  }
});

// Get interceptions by day
app.get('/api/stats/interceptions-weekly', async (req, res) => {
  try {
    const cacheKey = 'stats:interceptions:weekly';
    const cached = await redis.get(cacheKey);

    if (cached) {
      return res.json(JSON.parse(cached));
    }

    const result = await pool.query(`
      SELECT 
        TO_CHAR(created_at, 'Dy') as day_name,
        COUNT(*) as interception_count
      FROM interception_sessions
      WHERE created_at >= NOW() - INTERVAL '7 days'
      GROUP BY day_name, DATE_TRUNC('day', created_at)
      ORDER BY DATE_TRUNC('day', created_at) ASC
    `);

    const data = result.rows.map(row => ({
      day: row.day_name,
      count: parseInt(row.interception_count),
    }));

    await redis.setex(cacheKey, 300, JSON.stringify(data));
    res.json(data);
  } catch (error) {
    console.error('Error fetching weekly interceptions:', error);
    res.status(500).json({ error: 'Failed to fetch interception data' });
  }
});

// Get recent intelligence captures
app.get('/api/intelligence/recent', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const offset = parseInt(req.query.offset) || 0;

    const result = await pool.query(`
      SELECT 
        ic.id,
        ic.session_id,
        ic.capture_type,
        ic.captured_data,
        ic.risk_score,
        ic.created_at,
        ic.metadata,
        s.scammer_id,
        s.phone_number,
        s.location
      FROM intelligence_captures ic
      JOIN interception_sessions s ON ic.session_id = s.session_id
      ORDER BY ic.created_at DESC
      LIMIT $1 OFFSET $2
    `, [limit, offset]);

    const captures = result.rows.map(row => ({
      id: row.id,
      sessionId: row.session_id,
      type: row.capture_type,
      data: row.captured_data,
      riskScore: row.risk_score,
      timestamp: row.created_at,
      scammer: {
        id: row.scammer_id,
        phone: row.phone_number,
        location: row.location,
      },
      metadata: row.metadata,
    }));

    res.json({
      captures,
      pagination: {
        limit,
        offset,
        total: captures.length,
      },
    });
  } catch (error) {
    console.error('Error fetching intelligence captures:', error);
    res.status(500).json({ error: 'Failed to fetch intelligence data' });
  }
});

// Get active sessions
app.get('/api/sessions/active', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        session_id,
        scammer_id,
        phone_number,
        location,
        engagement_duration,
        data_points_collected,
        persona_type,
        created_at,
        last_activity
      FROM interception_sessions
      WHERE status = 'active'
      ORDER BY last_activity DESC
    `);

    const sessions = result.rows.map(row => ({
      sessionId: row.session_id,
      scammerId: row.scammer_id,
      phoneNumber: row.phone_number,
      location: row.location,
      duration: row.engagement_duration,
      dataPoints: row.data_points_collected,
      persona: row.persona_type,
      startTime: row.created_at,
      lastActivity: row.last_activity,
    }));

    res.json({ sessions, count: sessions.length });
  } catch (error) {
    console.error('Error fetching active sessions:', error);
    res.status(500).json({ error: 'Failed to fetch active sessions' });
  }
});

// Create new interception session
app.post('/api/sessions/create', async (req, res) => {
  const client = await pool.connect();
  try {
    const {
      scammerId,
      phoneNumber,
      initialMessage,
      detectedIntent,
      location,
      personaType,
    } = req.body;

    await client.query('BEGIN');

    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const result = await client.query(`
      INSERT INTO interception_sessions (
        session_id, scammer_id, phone_number, location, 
        persona_type, detected_intent, status, created_at, last_activity
      ) VALUES ($1, $2, $3, $4, $5, $6, 'active', NOW(), NOW())
      RETURNING *
    `, [sessionId, scammerId, phoneNumber, location, personaType, detectedIntent]);

    // Log initial message
    await client.query(`
      INSERT INTO session_messages (session_id, sender, message, timestamp)
      VALUES ($1, 'scammer', $2, NOW())
    `, [sessionId, initialMessage]);

    await client.query('COMMIT');

    const session = result.rows[0];

    // Broadcast new session to all connected clients
    broadcast({
      type: 'NEW_SESSION',
      data: {
        sessionId: session.session_id,
        scammerId: session.scammer_id,
        phoneNumber: session.phone_number,
        location: session.location,
      },
    });

    res.status(201).json({
      success: true,
      sessionId: session.session_id,
      message: 'Interception session created successfully',
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating session:', error);
    res.status(500).json({ error: 'Failed to create session' });
  } finally {
    client.release();
  }
});

// Add intelligence capture
app.post('/api/intelligence/capture', async (req, res) => {
  const client = await pool.connect();
  try {
    const {
      sessionId,
      captureType,
      capturedData,
      riskScore,
      metadata,
    } = req.body;

    await client.query('BEGIN');

    const result = await client.query(`
      INSERT INTO intelligence_captures (
        session_id, capture_type, captured_data, 
        risk_score, metadata, created_at
      ) VALUES ($1, $2, $3, $4, $5, NOW())
      RETURNING *
    `, [sessionId, captureType, JSON.stringify(capturedData), riskScore, JSON.stringify(metadata)]);

    // Update session data points
    await client.query(`
      UPDATE interception_sessions
      SET data_points_collected = data_points_collected + 1,
          last_activity = NOW()
      WHERE session_id = $1
    `, [sessionId]);

    await client.query('COMMIT');

    const capture = result.rows[0];

    // Broadcast new capture to all connected clients
    broadcast({
      type: 'NEW_CAPTURE',
      data: {
        id: capture.id,
        sessionId: capture.session_id,
        type: capture.capture_type,
        data: capturedData,
        riskScore: capture.risk_score,
        timestamp: capture.created_at,
      },
    });

    res.status(201).json({
      success: true,
      captureId: capture.id,
      message: 'Intelligence captured successfully',
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error capturing intelligence:', error);
    res.status(500).json({ error: 'Failed to capture intelligence' });
  } finally {
    client.release();
  }
});

// Get terminal logs (for live feed)
app.get('/api/logs/terminal', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;
    const sessionId = req.query.sessionId;

    let query = `
      SELECT log_type, message, timestamp, session_id
      FROM terminal_logs
    `;
    const params = [limit];

    if (sessionId) {
      query += ` WHERE session_id = $2`;
      params.push(sessionId);
    }

    query += ` ORDER BY timestamp DESC LIMIT $1`;

    const result = await pool.query(query, params);

    const logs = result.rows.map(row => ({
      type: row.log_type,
      message: row.message,
      timestamp: row.timestamp,
      sessionId: row.session_id,
    }));

    res.json({ logs });
  } catch (error) {
    console.error('Error fetching terminal logs:', error);
    res.status(500).json({ error: 'Failed to fetch logs' });
  }
});

// Report to authorities endpoint
app.post('/api/report/authorities', async (req, res) => {
  try {
    const { sessionId, reportType, additionalInfo } = req.body;

    const result = await pool.query(`
      INSERT INTO authority_reports (
        session_id, report_type, additional_info, 
        status, created_at
      ) VALUES ($1, $2, $3, 'pending', NOW())
      RETURNING *
    `, [sessionId, reportType, JSON.stringify(additionalInfo)]);

    const report = result.rows[0];

    // In production, this would trigger actual notification systems
    // (email, SMS, API calls to cyber crime portals, etc.)

    res.status(201).json({
      success: true,
      reportId: report.id,
      message: 'Report submitted to authorities successfully',
      status: 'pending_review',
    });
  } catch (error) {
    console.error('Error submitting report:', error);
    res.status(500).json({ error: 'Failed to submit report' });
  }
});

// Search scammer database
app.get('/api/scammers/search', async (req, res) => {
  try {
    const { phone, upiId, location, limit = 20 } = req.query;

    let query = `
      SELECT DISTINCT 
        scammer_id,
        phone_number,
        location,
        COUNT(session_id) as case_count,
        MAX(created_at) as last_seen,
        array_agg(DISTINCT detected_intent) as known_tactics
      FROM interception_sessions
      WHERE 1=1
    `;
    const params = [];
    let paramIndex = 1;

    if (phone) {
      query += ` AND phone_number ILIKE $${paramIndex}`;
      params.push(`%${phone}%`);
      paramIndex++;
    }

    if (location) {
      query += ` AND location ILIKE $${paramIndex}`;
      params.push(`%${location}%`);
      paramIndex++;
    }

    query += `
      GROUP BY scammer_id, phone_number, location
      ORDER BY case_count DESC
      LIMIT $${paramIndex}
    `;
    params.push(parseInt(limit));

    const result = await pool.query(query, params);

    const scammers = result.rows.map(row => ({
      scammerId: row.scammer_id,
      phoneNumber: row.phone_number,
      location: row.location,
      caseCount: parseInt(row.case_count),
      lastSeen: row.last_seen,
      knownTactics: row.known_tactics,
    }));

    res.json({ scammers, count: scammers.length });
  } catch (error) {
    console.error('Error searching scammers:', error);
    res.status(500).json({ error: 'Failed to search scammer database' });
  }
});

// Analytics endpoint - threat patterns
app.get('/api/analytics/threat-patterns', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        detected_intent as threat_type,
        COUNT(*) as occurrence_count,
        AVG(engagement_duration) as avg_duration,
        array_agg(DISTINCT location) as common_locations
      FROM interception_sessions
      WHERE created_at >= NOW() - INTERVAL '30 days'
      GROUP BY detected_intent
      ORDER BY occurrence_count DESC
    `);

    const patterns = result.rows.map(row => ({
      threatType: row.threat_type,
      count: parseInt(row.occurrence_count),
      avgDuration: parseFloat(row.avg_duration).toFixed(2),
      commonLocations: row.common_locations,
    }));

    res.json({ patterns });
  } catch (error) {
    console.error('Error fetching threat patterns:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined,
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  server.close(() => {
    console.log('HTTP server closed');
  });
  await pool.end();
  await redis.quit();
  process.exit(0);
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 Honeypot backend server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔌 WebSocket server ready for connections`);
});

module.exports = { app, server, pool, redis };
