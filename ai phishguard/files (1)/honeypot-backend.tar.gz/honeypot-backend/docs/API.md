# Honeypot API Documentation

## Base URL
```
https://api.honeypot.local
Development: http://localhost:3001
```

## Authentication

All API requests require authentication using one of the following methods:

### API Key (Recommended)
```bash
curl -H "X-API-Key: your-api-key-here" https://api.honeypot.local/api/stats/overview
```

### JWT Token
```bash
curl -H "Authorization: Bearer your-jwt-token" https://api.honeypot.local/api/sessions/active
```

## Rate Limits
- 100 requests per 15 minutes per IP address
- Burst of 20 requests allowed
- Rate limits can be increased for verified accounts

## Response Format

### Success Response
```json
{
  "data": { ... },
  "timestamp": "2026-01-31T12:00:00Z"
}
```

### Error Response
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": { ... }
}
```

## HTTP Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `429` - Too Many Requests
- `500` - Internal Server Error
- `503` - Service Unavailable

---

## Endpoints

### Health Check

#### GET /api/health
Check system health and service availability.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2026-01-31T12:00:00Z",
  "services": {
    "database": "connected",
    "redis": "connected",
    "websocket": "5 clients"
  }
}
```

---

### Statistics

#### GET /api/stats/overview
Get dashboard overview statistics.

**Response:**
```json
{
  "totalInterceptions": 342,
  "dataPointsCollected": 2847,
  "avgEngagementTime": "7.5",
  "uniqueScammers": 156,
  "activeSessions": 3,
  "systemStatus": "operational",
  "timestamp": "2026-01-31T12:00:00Z"
}
```

#### GET /api/stats/engagement-timeline
Get engagement metrics over time.

**Query Parameters:**
- `period` - Time period (24h, 7d, 30d). Default: 24h

**Response:**
```json
[
  {
    "timestamp": "2026-01-31T10:00:00Z",
    "avgEngagement": "6.30",
    "sessionCount": 12
  },
  ...
]
```

#### GET /api/stats/interceptions-weekly
Get weekly interception counts.

**Response:**
```json
[
  {
    "day": "Mon",
    "count": 28
  },
  ...
]
```

---

### Sessions

#### GET /api/sessions/active
Get all active interception sessions.

**Response:**
```json
{
  "sessions": [
    {
      "sessionId": "session_1706700003_ghi789",
      "scammerId": "scammer_003",
      "phoneNumber": "+91-8765432109",
      "location": "Delhi, NCR",
      "duration": 6.4,
      "dataPoints": 3,
      "persona": "Curious Persona",
      "startTime": "2026-01-31T11:30:00Z",
      "lastActivity": "2026-01-31T11:36:24Z"
    }
  ],
  "count": 1
}
```

#### POST /api/sessions/create
Create a new interception session.

**Request Body:**
```json
{
  "scammerId": "scammer_004",
  "phoneNumber": "+91-9876543210",
  "initialMessage": "Hello, you have won a prize!",
  "detectedIntent": "Lottery Scam",
  "location": "Mumbai, Maharashtra",
  "personaType": "Excited Persona"
}
```

**Response:**
```json
{
  "success": true,
  "sessionId": "session_1706700004_xyz123",
  "message": "Interception session created successfully"
}
```

---

### Intelligence

#### GET /api/intelligence/recent
Get recent intelligence captures.

**Query Parameters:**
- `limit` - Number of records (default: 50)
- `offset` - Pagination offset (default: 0)

**Response:**
```json
{
  "captures": [
    {
      "id": 145,
      "sessionId": "session_1706700001_abc123",
      "type": "UPI_ID",
      "data": {
        "upi_id": "scammer123@paytm",
        "timestamp": "2026-01-31T10:30:00Z"
      },
      "riskScore": 85,
      "timestamp": "2026-01-31T10:30:15Z",
      "scammer": {
        "id": "scammer_001",
        "phone": "+91-7654321098",
        "location": "Bengaluru, Karnataka"
      },
      "metadata": {}
    }
  ],
  "pagination": {
    "limit": 50,
    "offset": 0,
    "total": 50
  }
}
```

#### POST /api/intelligence/capture
Add a new intelligence capture.

**Request Body:**
```json
{
  "sessionId": "session_1706700003_ghi789",
  "captureType": "BANK_DETAILS",
  "capturedData": {
    "bank": "HDFC",
    "account_hint": "****5678"
  },
  "riskScore": 90,
  "metadata": {
    "extraction_method": "conversation_analysis"
  }
}
```

**Response:**
```json
{
  "success": true,
  "captureId": 146,
  "message": "Intelligence captured successfully"
}
```

---

### Scammer Database

#### GET /api/scammers/search
Search the scammer database.

**Query Parameters:**
- `phone` - Phone number (partial match)
- `upiId` - UPI ID (partial match)
- `location` - Location (partial match)
- `limit` - Results limit (default: 20)

**Response:**
```json
{
  "scammers": [
    {
      "scammerId": "scammer_001",
      "phoneNumber": "+91-7654321098",
      "location": "Bengaluru, Karnataka",
      "caseCount": 12,
      "lastSeen": "2026-01-31T10:30:00Z",
      "knownTactics": ["UPI Phishing", "Tech Support Scam"]
    }
  ],
  "count": 1
}
```

---

### Analytics

#### GET /api/analytics/threat-patterns
Get threat pattern analysis.

**Response:**
```json
{
  "patterns": [
    {
      "threatType": "UPI Phishing",
      "count": 156,
      "avgDuration": "8.45",
      "commonLocations": ["Bengaluru", "Mumbai", "Delhi"]
    },
    {
      "threatType": "Tech Support Scam",
      "count": 89,
      "avgDuration": "12.30",
      "commonLocations": ["Kolkata", "Chennai"]
    }
  ]
}
```

---

### Reporting

#### POST /api/report/authorities
Submit a report to authorities.

**Request Body:**
```json
{
  "sessionId": "session_1706700001_abc123",
  "reportType": "CYBER_CRIME",
  "additionalInfo": {
    "urgency": "high",
    "evidence": ["UPI ID", "Phone Number", "Location"],
    "notes": "Active scammer with multiple victims"
  }
}
```

**Response:**
```json
{
  "success": true,
  "reportId": 42,
  "message": "Report submitted to authorities successfully",
  "status": "pending_review"
}
```

---

### Terminal Logs

#### GET /api/logs/terminal
Get terminal logs for live feed.

**Query Parameters:**
- `limit` - Number of logs (default: 100)
- `sessionId` - Filter by session (optional)

**Response:**
```json
{
  "logs": [
    {
      "type": "success",
      "message": "Connection established with scammer endpoint",
      "timestamp": "2026-01-31T11:30:00Z",
      "sessionId": "session_1706700003_ghi789"
    },
    {
      "type": "analyzing",
      "message": "Analyzing scammer intent...",
      "timestamp": "2026-01-31T11:30:02Z",
      "sessionId": "session_1706700003_ghi789"
    }
  ]
}
```

---

## WebSocket API

### Connection
```javascript
const ws = new WebSocket('wss://api.honeypot.local/ws?token=your-jwt-token');
```

### Subscribing to Topics
```javascript
ws.send(JSON.stringify({
  type: 'SUBSCRIBE',
  topics: ['sessions', 'intelligence', 'terminal', 'stats']
}));
```

### Available Topics
- `sessions` - New and updated sessions
- `intelligence` - New intelligence captures
- `terminal` - Terminal logs
- `stats` - Statistics updates

### Events Received

#### NEW_SESSION
```json
{
  "type": "NEW_SESSION",
  "topic": "sessions",
  "data": {
    "sessionId": "session_xxx",
    "scammerId": "scammer_xxx",
    "phoneNumber": "+91-xxx",
    "location": "City, State"
  },
  "timestamp": "2026-01-31T12:00:00Z"
}
```

#### NEW_CAPTURE
```json
{
  "type": "NEW_CAPTURE",
  "topic": "intelligence",
  "data": {
    "id": 150,
    "sessionId": "session_xxx",
    "type": "UPI_ID",
    "data": { ... },
    "riskScore": 85
  },
  "timestamp": "2026-01-31T12:00:00Z"
}
```

---

## Error Codes

| Code | Description |
|------|-------------|
| `AUTH_REQUIRED` | Authentication is required |
| `INVALID_API_KEY` | The provided API key is invalid |
| `TOKEN_EXPIRED` | JWT token has expired |
| `PERMISSION_DENIED` | Insufficient permissions |
| `VALIDATION_ERROR` | Request validation failed |
| `NOT_FOUND` | Resource not found |
| `RATE_LIMIT_EXCEEDED` | Too many requests |
| `DATABASE_ERROR` | Database operation failed |
| `INTERNAL_ERROR` | Internal server error |

---

## SDKs and Libraries

Coming soon:
- JavaScript/TypeScript SDK
- Python SDK
- Go SDK

---

## Support

For API support and questions:
- Documentation: https://docs.honeypot.local
- Email: api-support@honeypot.local
- GitHub: [repository-url]/issues
